# Inventory Persistence
### A BONELAB mod which allows the player's inventory to persist from one level to the next and save between sessions.

## Info
### - Contains Bonemenu options for:
#### + Blacklisting levels from saving/loading items
#### + Enabling Inventory/Ammo saving and loading

### There is some Fusion support, as when you join a Fusion server items will not get placed in body slots, only spawned in front of you.

## Credits
### doge15567: Gave inspiration for this mod as well as helped with the icon cause Paint.Net
